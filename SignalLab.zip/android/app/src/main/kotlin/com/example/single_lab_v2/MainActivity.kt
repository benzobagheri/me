package dev.vlab.signal_lab

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
