
import 'dart:convert';

import 'package:get/get.dart';
import 'package:signal_lab/core/helper/shared_pref_helper.dart';
import 'package:signal_lab/core/route/route.dart';
import 'package:signal_lab/core/utils/my_strings.dart';
import 'package:signal_lab/data/model/general_setting/general_setting_main_model.dart';
import 'package:signal_lab/data/model/global/response_model/response_model.dart';
import 'package:signal_lab/data/repo/auth/general_setting_repo.dart';
import 'package:signal_lab/views/components/snackbar/show_custom_snackbar.dart';

class SplashController extends GetxController{

  GeneralSettingRepo repo ;
  SplashController({required this.repo,}){
    gotoNext();
  }

  void gotoNext()async{
    bool isRemember = repo.apiClient.sharedPreferences.getBool(SharedPreferenceHelper.rememberMeKey)??false;
    getGsData(isRemember);

  }

  Future<void> getGsData(bool isRemember)async{
    ResponseModel response = await repo.getGeneralSetting();

    if(response.statusCode == 200){
      GeneralSettingMainModel model = GeneralSettingMainModel.fromJson(jsonDecode(response.responseJson));
      if(model.status?.toLowerCase() == "success"){
        repo.storeGeneralSetting(model);
        checkAndGo(isRemember);
      }else{
        MySnackbar.error(errorList: model.message?.error ?? [MyStrings.somethingWentWrong],);
      }
    }else{
      MySnackbar.error(errorList: [response.message]);
    }
  }

  void checkAndGo(bool isRemember){
    if(isRemember){
      Get.offAndToNamed(RouteHelper.homeScreen);
    }else{
      Get.offAndToNamed(RouteHelper.signInScreen);
    }
  }
}